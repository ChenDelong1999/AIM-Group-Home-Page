---
title: 张嘉韬
role: 2015级本科生（浙江大学博士生）
avatar_filename: avatar.jpg
bio: 2015级本科生
interests:
  - 机器人自主决策与任务规划
social:
  - display:
      header: false
    link: mailto:zjt9727@gmail.com
    icon_pack: fas
    icon: envelope
superuser: false
user_groups:
  - 已毕业学生
---
目前就读与浙江大学，研究方向为机器人自主决策和任务规划、具身智能。
